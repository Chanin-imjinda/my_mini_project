<?php
    require_once 'header.php';

    if(!isset($_GET['product_id'])){
        header("refresh: 0; url=main1.php");
        }

    require_once 'conn.php';

    $sql = "SELECT * FROM product WHERE product_id='$_GET[product_id]'";
    $result = $conn->query($sql);
    if(!$result){
        die("Error : ". $conn->$conn_error);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>

<body>
    <?php
        require_once 'navbar.php';
    ?>
    <div class="col-12 mt-1 p-md-2">
        <div class="row">
            <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $output = "<div class='col-md-3'>";
                            $output .= "<div class='card bg-mix-dark-1'>";
                            $output .= "<img src='".$row["pro_pic1"]."'class='card-img-top'>";
                            $output .= "<div class='card-body'>";
                            $output .= "<h5 class='card-title fw-bold'>".$row["Title"]."</h5>";
                            $output .= "<p class='small card-text'>".$row["Description"]."</p>";
                            $output .= '<small class="pe-3">ผู้ขาย</small>'.($row["shopid"]);
                            $output .= "<div class='d-flex flex-column'>";
                            $output .= "</div>";
                            $output .= "</div>";
                            $output .= "</div>";
                            $output .= "</div>";
                            echo $output;
                            }
                        }else {
                            echo "0 results";
                        }
                $conn->close();
            ?>                   
        </div>
    </div>
</body>