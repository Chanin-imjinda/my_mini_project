<?php
    require_once 'conn.php';
    require_once 'header.php';
    $sql = "SELECT * FROM product";
    $result = $conn->query($sql);
    if(!$result) {
        die("Error : ". $conn->$conn_error);
    }   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>

<body class="bg-dark text-white">
        <?php
            require_once 'navbar.php';
        ?>
        <div class="w3-display-container">
            <img src="img/banner1.jpg" class="img-fluid" style="width: 100%;">
            <div class="w3-display-topleft w3-text-white" style="padding: 100px 50px">
                <h1 class="fs-1 w-100">New arrivals</h1>
                <h1 class="fs-2 w-100">COLLECTION 2016</h1>
                <form>
                    <input class="form-control float-none" type="text" placeholder="Search" aria-label="Search" autocomplete="off" required>
                </form>
            </div>
        </div>

        <div class="p-4 mb-2 bg-dark text-white">
            <h1>นักวาด</h1>
        </div>
            
        <div class="col-12 mt-1 p-md-2">
                <div class="row">
                    <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                $output = "<div class='col-md-3'>";                              
                                $output .= "<div class='card bg-mix-dark-1'>";
                                $output .= "<img src='".$row['pro_pic1']."' class='card-img-top'>";
                                $output .= "<div class='card-body'>";
                                $output .= "<h5 class='card-title fw-bold'>".$row['Title']."</h5>";
                                $output .= "<p class='small card-text'>".$row['Description']."</p>";
                                $output .= '<small class="pe-3">ผู้ขาย</small>'.($row['shopid']);
                                $output .= "<br><a href='productdetail.php?product_id=".$row['product_id']."' class='btn btn-primary mb-2 mt-3'>Start ".$row['price']." บาท</a>"; 
                                $output .= "<div class='d-flex flex-column'>";
                                $output .= "</div>";
                                $output .= "</div>";
                                $output .= "</div>";
                                $output .= "</div>";
                                echo $output;
                            }
                        }else {
                            echo "0 results";
                        }
                        $conn->close();
                     ?> 
                </div>   
        </div>

        <div>

        </div>
</body>
</html>