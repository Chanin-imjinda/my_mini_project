<?php
session_start();  // เริ่มต้นเซสชัน

$conn = new mysqli('localhost','root','','art_shop');
$conn->query("SET NAMES utf8");


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['email'];
        $password = $_POST['password'];
    
        // เช็คว่า username และ password ถูกต้อง
        $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
        $result = $conn->query($sql);
    
        if ($result && $result->num_rows == 1) {
            // Username และ password ถูกต้อง
            $_SESSION['email'] = $email;
            echo '<script>alert("Login successful!");</script>';
            header("refresh: 1; url= main.php");
            exit();
        } else {
            $_SESSION['email_input'] = $email;  // เก็บ username ที่กรอก
            $_SESSION['password_input'] = $password;  // เก็บ password ที่กรอก
            echo '<script>alert("Login failed. Invalid username or password!");</script>';
            echo '<script>window.history.back();</script>';
            exit();
        }
    }
?>
