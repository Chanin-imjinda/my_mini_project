<?php 
  require_once 'conn.php';
  require_once 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Navbar</title>
  <link rel="stylesheet" href="css/sidebar.css">
</head>
<body>
  <!-- Sidebar -->
  <div class="w3-sidebar w3-bar-block w3-border-right" style="display:none" id="mySidebar">
    <button onclick="w3_close()" class="w3-bar-item w3-large">Close &times;</button>
      <a href="allproduct.php" class="w3-bar-item w3-button">product</a>
      <a href="allseller.php" class="w3-bar-item w3-button">seller</a>
      <a href="alluser.php" class="w3-bar-item w3-button">user</a>
      <a href="logout.php" class="w3-bar-item w3-button">logout</a>
    </div>
  <!-- Page Content -->
  <div class="w3-teal">
    <button class="w3-button w3-teal w3-xlarge" onclick="w3_open()">☰</button>
    <div class="w3-container">
    </div>
  </div>
    <script>
    function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
    }

    function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
    }
  </script>
</body>
</html>