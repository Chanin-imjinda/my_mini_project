<?php 
  require_once 'conn.php';
  require_once 'header.php';
?>

<nav class="navbar navbar-dark text-white " aria-label="First navbar example" style="background-color:#15191E">
    <ul class="nav nav-underline large-text" style="margin-left:50%">
        <li class="nav-item">
            <a class="nav-link text-white large-text" href="#">All</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white large-text" href="#">link</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white large-text" href="#">Link</a>
        </li>
    </ul>
</nav>