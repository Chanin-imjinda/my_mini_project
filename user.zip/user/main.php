<?php
    require_once 'conn.php';
    require_once 'header.php';

    $sql = "SELECT * FROM product WHERE price IS NOT NULL";
    $result = $conn->query($sql);
    if(!$result) {
        die("Error : ". $conn->$conn_error);
    }   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>

<body class="bg-black text-white">
        <?php
            require_once 'header_all.php';
        ?>
        <main>
        <div class="w3-display-container">
            <img src="img/banner1.jpg" class="img-fluid" style="width: 100%; height: 80vh; object-fit: cover;">
            <div class="w3-display-topleft w3-text-white" style="padding: 100px 50px">
                <h1 class="fs-1 w-100" style="margin-top: 300px; margin-left: 20% ; font-weight:bold ">VITIVE</h1>
                <h1 class="fs-2 w-100" style="margin-left: 20% ">is a community where everyone</h1>
                <h1 class="fs-2 w-100" style="margin-left: 20% ">can support creators with commission.</h1>
            </div>
        </div>
        <?php
            require_once 'navbar1.php';
        ?>
            <div style="margin-left: 10% ; margin-right: 10%">
                <div class="col-12 mt-4 p-md-1">
                        <div class="row">
                            <?php
                                    if ($result->num_rows > 0) {
                                        while($row = $result->fetch_assoc()) {

                                                $output = "<div class='col-md-2 p-2' style='margin-left: 60px'>";                              
                                                    $output .= "<div class='card text-white bg-dark mb-3' style='width: 20rem;'>";
                                                        $output .= "<img src='".$row['pro_pic1']."' class='card-img-top' width='300px' height='300px'>";
                                                            $output .= "<div class='card-body'>";
                                                                $output .= "<h5 class='card-title fw-bold' href=''>".$row['Title']."</h5>";
                                                                $output .= "<p class='small card-text'>".$row['Description']."</p>";
                                                                $output .= '<small class="pe-3">ผู้ขาย</small>'.($row['username']);
                                                                $output .= "<br><a href='productdetail.php?product_id=".$row['product_id']."' class='btn btn-primary mb-2 mt-3'>Start ".$row['price']." บาท</a>"; 
                                                            $output .= "<div class='d-flex flex-column'>";
                                                    $output .= "</div>";
                                                $output .= "</div>";
                                            $output .= "</div>";
                                        $output .= "</div>";  

                                        echo $output;
                                        }
                                    }else {    
                                    }
                                        $conn->close();
                                    ?>
                            </div>   
                        </div>
                </div>
            </div>
        </main>
</body>
</html>