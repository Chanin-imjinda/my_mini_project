<?php 

  require_once 'conn.php';
  require_once 'header.php';

  $sql = "SELECT * FROM shopowners ";
    $result = $conn->query($sql);
    if(!$result) {
        die("Error : ". $conn->$conn_error);
  } 

?>

