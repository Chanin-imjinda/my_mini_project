<?php
    require_once 'header.php';

    if(!isset($_GET['product_id'])){
        header("refresh: 0; url=main.php");
        } 
    require_once 'conn.php';

    $sql = "SELECT * FROM product JOIN shopowners USING(shopid) WHERE product_id='$_GET[product_id]'";
    $result = $conn->query($sql);
    if(!$result){
        die("Error : ". $conn->$conn_error);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>

<body class="bg-dark text-white">
    <?php
        require_once 'header_all.php';
    ?>
    <main style="margin-left: 10% ; margin-right: 10%">
        <div>
                <?php
                    if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {

                    $output .= "<div>";
                        $output .= "<div class='row align-items-md-stretch' style='margin-left: 10% ; margin-right: 10% ; margin-top: 40px'>";
                            
                        //blox รูปภาพ
                            $output .= "<div class='col-md-8'>";
                                $output .= "<div id='carouselExampleControls' class='carousel slide' data-bs-ride='carousel'>";
                                    $output .= "<div class='carousel-inner'>";
                                        $output .= "<div class='carousel-item active'>";
                                            $output .= "<img src='".$row["pro_pic1"]." 'class='figure-img img-fluid rounded img-full'>";
                                        $output .= "</div>";
                                        $output .= "<div class='carousel-item'>";
                                            $output .= "<img src='".$row["pro_pic2"]." 'class='figure-img img-fluid rounded img-full'>";
                                        $output .= "</div>";
                                        $output .= "<div class='carousel-item'>";
                                            $output .= "<img src='".$row["pro_pic3"]." 'class='figure-img img-fluid rounded img-full'>";
                                        $output .= "</div>";
                                    $output .= "</div>";

                                    $output .= "<button class='carousel-control-prev' type='button' data-bs-target='#carouselExampleControls' data-bs-slide='prev'>";
                                        $output .= "<span class='carousel-control-prev-icon' aria-hidden='true'></span>";
                                        $output .= "<span class='visually-hidden'>Previous</span>";
                                    $output .= "</button>";

                                    $output .= "<button class='carousel-control-next' type='button' data-bs-target='#carouselExampleControls' data-bs-slide='next'>";
                                        $output .= "<span class='carousel-control-next-icon' aria-hidden='true'></span>";
                                        $output .= "<span class='visually-hidden'>Next</span>";
                                    $output .= "</button>";
                                    
                                $output .= "</div>";
                            $output .= "</div>";

                            //blox ข้อความ
                            $output .= "<div class='col-md-4'>";
                                $output .= "<div class='h-40 p-5 bg-white border rounded-3 text-dark'>";
                                $output .= "<h2 class='card-title fw-bold' href=''>".$row['Title']."</h2>";
                                        $output .= "<p class='small card-text'>".$row['Description']."</p>";
                                        $output .= "<button class='btn btn-outline-secondary' type='button'>Example button</button>";
                                $output .= "</div>";

                                $output .= "<div class='h-40 p-5 bg-white border rounded-3 text-dark' style='margin-top: 30px'>";
                                    $output .= "<h2>Add borders</h2>";
                                        $output .= "<p>Or, keep it light and add a border for some added definition to the boundaries of your content. 
                                                    Be sure to look under the hood at the source HTML here as we've adjusted the alignment and sizing of both column's content for equal-height.</p>";
                                        $output .= "<button class='btn btn-outline-secondary' type='button'>Example button</button>";
                                $output .= "</div>";
                            $output .= "</div>";
                    $output .= "</div>";

                        $output .= "<div>";
                                    $output .= "<div class='row align-items-md-stretch' style='margin-left: 10% ; margin-right: 10%; margin-top: 30px' >";
                                                    $output .= "<div class='col-md-6'>";
                                                        $output .= "<div class='h-100 p-5 text-dark bg-white'>";
                                                            $output .= "<a class='d-block link-dark text-decoration-none' id='dropdownUser1' data-bs-toggle='dropdown' aria-expanded='true'>";
                                                                $output .= "<img src='".$row["shop_pic"]."' alt='mdo' width='70' height='70' class='rounded-circle'>";                                     
                                                                $output .= "</a><br>";

                                                                $output .= "<p>Swap the background-color utility and add a `.text-*` color utility to mix up the jumbotron look. Then, mix and match with additional component themes and more.</p>";
                                                                $output .= "";
                                                            $output .= "</div>";
                                                        $output .= "</div>";

                                                        $output .= "<div class='col-md-6'>";
                                                            $output .= "<div class='h-100 p-5 text-dark bg-white'>";
                                                                $output .= "<a class='d-block link-dark text-decoration-none' id='dropdownUser1' data-bs-toggle='dropdown' aria-expanded='true'>";
                                                                $output .= "<img src='".$row["shop_pic"]."' alt='mdo' width='70' height='70' class='rounded-circle'>";                                     
                                                                $output .= "</a><br>";

                                                                $output .= "<p>Swap the background-color utility and add a `.text-*` color utility to mix up the jumbotron look. Then, mix and match with additional component themes and more.</p>";
                                                                $output .= "";
                                                            $output .= "</div>";
                                                        $output .= "</div>";
                                                    $output .= "</div>";
                                    $output .= "</div>";
                        $output .= "</div>";
                    $output .= "</div>";
                        echo $output;
                            }
                        }else {
                            echo "0 results";
                            }
                        $conn->close();
                    ?>
        </div>
    </main>
</body>