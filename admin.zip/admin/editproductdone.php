<?php
require 'conn.php';
$sql_update="UPDATE product SET Title='$_POST[Title]',Description='$_POST[Description]' ,price='$_POST[price]' ,price_descript='$_POST[price_descript]', price2='$_POST[price2]' ,price_descript2='$_POST[price_descript2]' ,pro_pic1='$_POST[pro_pic1]' WHERE product_id='$_POST[product_id]' ";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Insert Success <br>";
header("refresh: 1; url=http://localhost/vitive/admin/allproduct.php");
}

?>