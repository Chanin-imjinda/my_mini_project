<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="styletop.css">
    <title>Edit</title>
</head>

<body> 
    <?php 
      require_once 'navbar.php';
    ?>
    <br>
    <form class="container" id="form1" name="form1" method="post" action="insertproductdone.php">
        <h1>Insert Product</h1><br>
        <P>
            <label for="product_id">ID</label>
            <input type="number" name="product_id" id="product_id"/>
        </p>

        <p>
            <label for="Title">Title</label>
            <input type="text" name="Title" id="Title">
        </p>

        <p>
            <label for="Description">Description</label>
            <input type="text" name="Description" id="Description">
        </p>

        <p>
            <label for="price">Price</label>
            <input type="number" name="price" id="price">
        </p>

        <p>
            <label for="price_descript">Price Description</label>
            <input type="text" name="price_descript" id="price_descript">
        </p>

        
        <p>
            <label for="price2">Price 2</label>
            <input type="number" name="price2" id="price2">
        </p>

        <p>
            <label for="price_descript2">Price Description</label>
            <input type="text" name="price_descript2" id="price_descript2">
        </p>

        <p>
            <label for="pro_pic1">Product Picture (only image URL)</label>
            <input type="text" name="pro_pic1" id="pro_pic1">
        </p>


        <input type="submit" class="btn btn-success" value="confirm">
        <a class="btn btn-danger" href='alluser.php'>cancel</a>
    </form>
</body>
</html> 