<?php 
    session_start();
    if(session_destroy()){
        header("location: http://localhost/Miniproject/user/login.php");
    }
?>