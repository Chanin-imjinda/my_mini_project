<?php

require 'conn.php';
$sql = "SELECT * FROM product WHERE product_id='$_GET[product_id]'";
$result = $conn->query($sql);
$row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>


<body>

    

<div class="container">
        <h1>Edit Customer</h1><br>
    <form id="form1" name="form1" method="post" action="editproductdone.php">
    <p>
            <label for="product_id">ID</label>
            <input type="text" name="product_id" id="product_id" value="<?=$row['product_id'];?>" readonly>
        </p>
        <p>

            <label for="Title">ชื่อ</label>
            <input type="text" name="Title" id="Title" value="<?=$row['Title'];?>">

        </p>

        <p>

            <label for="Description">คำอธิบาย</label>

            <input type="text" name="Description" id="Description" value="<?=$row['Description'];?>">

        </p>

        <p>

            <label for="price">ราคา 1</label>

            <input type="text" name="price" id="price" value="<?=$row['price'];?>">

        </p>

        <p>

            <label for="price_descript">คำอธิบายราคา</label>

            <input type="text" name="price_descript" id="price_descript" value="<?=$row['price_descript'];?>">

        </p>

        <p>

            <label for="price2">ราคา 1</label>

            <input type="text" name="price2" id="price2" value="<?=$row['price2'];?>">

        </p>

        <p>

            <label for="price_descript2">คำอธิบายราคา</label>

            <input type="text" name="price_descript2" id="price_descript2" value="<?=$row['price_descript2'];?>">

        </p>
        
        <p>

            <label for="pro_pic1">รูปภาพ</label>

            <input type="text" name="pro_pic1" id="pro_pic1" value="<?=$row['pro_pic1'];?>">

        </p>

        <input type="submit" class="btn btn-success" value="บันทึก">
        <a class="btn btn-success" href='allproduct.php'>Home</a>
    </form>
</body>

</html>