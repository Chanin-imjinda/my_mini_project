<?php
    require 'conn.php';
    require_once 'header.php';
    $sql = "SELECT * FROM product";
    
    $result = $conn->query($sql);
    if(!$result){
        die("Error : ". $conn->$conn_error);
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>Admin</title>
</head>

<body>
    <?php 
      require_once 'navbar.php';
    ?>
    <br>
    <div class="container">
        <h1>Product check</h1>
        <br>
        <from class="search" method="post">
            <input type="search" class="form-control form-control-dark" placeholder="Search..." aria-label="Search">
            <button type="submit"><span class="icon_search"></span></button>
        </from>
          <br>
        <table class="table">  
          <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col-4">Title</th>
                    <th scope="col-4">Description</th>
                    <th scope="col-4">Edit</th>
                    <th scope="col-4">Delete</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    if (isset($_POST['search'])) {
                    $search = $_POST['search'];
                    $sql = "SELECT * FROM products WHERE Title like '%$search%'";
                    $stmt = $conn->prepare($sql);
                    $searchParam = "%" . $search . "%";
                    $stmt->bind_param("s", $searchParam);
                    $stmt->execute();
                    $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr><td>".$row["product_id"]."</td>"."<td>".$row["Title"]."</td>"."<td>".$row["Description"]."</td>"
                                ."<td>"."<a class='btn btn-warning' href='editproduct.php?product_id=".$row["product_id"]."'>Edit</a>"."</td>"
                                ."<td>"."<a class='btn btn-danger' href='deleteproduct.php?product_id=".$row["product_id"]."'>Delete</a>"."</td>";
                                echo "</tr>";
                                }
                        } else {
                        echo "0 results";
                        }
                    $stmt->close();
                    }
                    if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>".$row["product_id"]."</td>"."<td>".$row["Title"]."</td>"."<td>".$row["Description"]."</td>"
                        ."<td>"."<a class='btn btn-warning' href='editproduct.php?product_id=".$row["product_id"]."'>Edit</a>"."</td>"
                        ."<td>"."<a class='btn btn-danger' href='deleteproduct.php?product_id=".$row["product_id"]."'>Delete</a>"."</td>";
                            }
                        } else {
                                echo "0 results";
                        }
                    $conn->close();
                ?>
            </tbody>
        </table>
        <a class="btn btn-success" href='insertproduct.php'>Insert Product</a>
    </div>
</body>

</html>