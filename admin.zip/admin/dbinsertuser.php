<?php
require 'conn.php';

$sql_update="INSERT INTO users(uid,username,email,password) VALUES ('$_POST[uid]','$_POST[username]','$_POST[email]','$_POST[password]')";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Insert Success <br>";
header("refresh: 1; url=alluser.php");
}

?>