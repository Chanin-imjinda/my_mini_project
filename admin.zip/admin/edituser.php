<?php
    require_once 'conn.php';
    require_once 'header.php';

    $sql = "SELECT * FROM users WHERE uid='$_GET[uid]'";
    $result = $conn->query($sql);
    if(!$result){
        die("Error : ". $conn->$conn_error);
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Edit</title>
</head>
<div class="row">
            <div class="col-12 py-5 d-flex align-items-center">
                <a href='movie.php'><i class="bi bi-arrow-left-circle" style="font-size:40px;"></i></a>
                <h2 class="ms-4">Edit User</h2>
            </div>
<body class="container">
    <form id="form1" name="form1" method="post" action="editsuccess.php">
        <p>
            <label for="uid">ID</label>
            <input type="number" name="uid" id="uid" value="<?=$row['uid'];?>" readonly >
        </p>
        <p>

            <label for="username">ชื่อผู้ใช้</label>
           
            <input type="text" name="username" id="username" value="<?=$row['username'];?>" />

        </p>
        <p>

            <label for="email">อีเมล</label>

            <input type="text" name="email" id="email" value="<?=$row['email'];?>" />

        </p>
        <p>

            <label for="password">รหัสผ่าน</label>
            <input type="text" name="password" id="password" value="<?=$row['password'];?>" />

        </p>
        <input type="submit" class="btn btn-success" value="บันทึก">
        <a class="btn btn-success" href='main1.php'>Home</a>
    </form>
</body>

</html>