<?php
require 'conn.php';
$sql="DELETE FROM product WHERE product_id='$_POST[product_id]' ";
$result= $conn->query($sql);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Delete Success <br>";
header("refresh: 1; url=http://localhost/vitive/admin/allproduct.php");
}

?>