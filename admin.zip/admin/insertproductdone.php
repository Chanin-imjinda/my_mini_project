<?php
require 'conn.php';

$sql_update="INSERT INTO product(product_id,uid,Title,Description,price,price_descript,price2,price_descript2,pro_pic1) 
VALUES ('$_POST[product_id]', 2 ,'$_POST[Title]','$_POST[Description]','$_POST[price]','$_POST[price_descript]','$_POST[price2]','$_POST[price_descript2]','$_POST[pro_pic1]')";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Insert Success <br>";
header("refresh: 1; url=alluser.php");
}

?>